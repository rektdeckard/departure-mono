# HELLO!

Thanks for trying Departure Mono (departuremono.com), licensed under the SIL OFL. Send your questions and suggestions to hello@helenazhang.com. Enjoy!

— Helena Zhang (helenazhang.com)

# FONT INFORMATION

Version 1.346 supports 763 total glyphs, including:

- Basic Latin, Latin-1, Latin Extended-A, and most Latinate languages
- Basic Greek
- Simple box-drawing characters and selected symbols

# USAGE

For pixel-perfect results, set the font size to increments of 11px.

If you're okay with folding to half pixels, try -.5px tracking at 11px (-1px at 22px, etc.) for a more comfortable read.