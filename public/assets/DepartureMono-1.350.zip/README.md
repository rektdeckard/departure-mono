# HELLO!

Thanks for trying Departure Mono (departuremono.com), licensed under the SIL OFL. Send your questions and suggestions to hello@helenazhang.com. Enjoy!

— Helena Zhang (helenazhang.com)

# FONT INFORMATION

Version 1.350 features 775 glyphs, including support for:

- Basic Latin, Latin-1, Latin Extended-A, and most Latinate languages
- Basic Greek
- Small caps
- Old-style numerals and fractions
- Simple box-drawing characters and selected symbols

# USAGE

For pixel-perfect results, set the font size to increments of 11px.

Experiment with tighter tracking (letter-spacing) for a more comfortable read in some cases — or wider tracking for a sci-fi effect.

# CHANGELOG

v1.350
- 775 glyphs
- Added fractions: ↉ ⅓ ⅔ ⅕ ⅖ ⅗ ⅘ ⅙ ⅚ ⅐ ⅑
- Added a centered alternate for *
- Adjusted old-style numerals 0, 1, 2 to be x-height
- Adjusted ½ ¼ ¾ ⅛ ⅜ ⅝ ⅞ ‰ to fit in bounding box
- Adjusted curly brackets to horizontally align with other brackets
- Adjusted position of * and °

v1.346
- 763 glyphs