# HELLO!

Thanks for trying Departure Mono (departuremono.com), licensed under the SIL OFL. Send your questions and suggestions to hello@helenazhang.com. Enjoy!

— Helena Zhang (helenazhang.com)

# FONT INFORMATION

The latest version supports 763 total glyphs, including:

- Basic Latin, Latin-1, Latin Exentded-A, and most Latinate languages
- Basic Greek
- Simple box-drawing characters and selected symbols

# USAGE

For best results, use at increments of 11px.
